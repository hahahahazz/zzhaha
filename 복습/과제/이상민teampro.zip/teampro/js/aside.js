document.addEventListener("DOMContentLoaded" , () => {

    let $imgs = document.querySelectorAll(".people_wrap");

    let colors = ["rgb(184, 202, 219)", "rgb(197, 202, 207)"
    , "rgb(243, 193, 100)", "rgb(158, 250, 163)"
    , "rgb(212, 192, 250)", "rgb(248, 178, 187)"
    , "rgb(204, 206, 186)"];

    $imgs.forEach((item, index) => {
        item.style.backgroundColor = colors[index % colors.length];
    });
});
